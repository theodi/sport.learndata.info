module.exports = {
    options: {
        courseFile: '<%= sourcedir %>course/*/course.json',
        blocksFile: '<%= sourcedir %>course/*/blocks.json'
    }
}
